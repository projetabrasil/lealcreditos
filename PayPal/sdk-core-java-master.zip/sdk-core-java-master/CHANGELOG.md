### CHANGELOG

#### V1.6.2 (August 13, 2014)

   * Change scope of QueryParameters's method
   * Fix for issue #28 (https://github.com/paypal/sdk-core-java/issues/28)

#### V1.6.1 (June 16, 2014)

   * Fix connection reattempt logic

#### V1.6.0 (May 13, 2014)

   * Update core to support future payment

#### V1.5.0 (September 26, 2013)

   * Updating core to support genio

